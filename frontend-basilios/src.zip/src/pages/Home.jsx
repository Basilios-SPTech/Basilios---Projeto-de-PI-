// src/pages/Home.jsx
import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

const CHAVE_STORAGE = "produtos-basilios";

function formatBRL(value) {
  try {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
      maximumFractionDigits: 2,
    }).format(Number(value || 0));
  } catch {
    return `R$ ${value}`;
  }
}

export default function Home() {
  const [produtos, setProdutos] = useState([]);
  const location = useLocation();

  // Função que lê do storage e normaliza os campos
  const loadFromStorage = () => {
    try {
      const raw = localStorage.getItem(CHAVE_STORAGE);
      const arr = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(arr)) return setProdutos([]);

      // Normaliza pra suportar os dois formatos
      const normalized = arr.map((p, i) => {
        const nome = p.nome ?? p.name ?? "";
        const descricao = p.descricao ?? p.description ?? "";
        const preco = p.preco ?? p.price ?? 0;
        const imagem = p.imagem ?? p.imageDataUrl ?? "";
        const id = p.id ?? String(p.index ?? i);
        return { id, nome, descricao, preco, imagem };
      });

      setProdutos(normalized);
    } catch {
      setProdutos([]);
    }
  };

  // 1) Montagem + navegação: sempre que entrar na Home, recarrega
  useEffect(() => {
    loadFromStorage();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.key]);

  // 2) Evento custom "produtos-updated" (disparado pelo CadastrarProduto.jsx)
  useEffect(() => {
    const handler = () => loadFromStorage();
    window.addEventListener("produtos-updated", handler);
    // evento 'storage' dispara quando outro TAB altera o localStorage
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("produtos-updated", handler);
      window.removeEventListener("storage", handler);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!produtos?.length) {
    return (
      <section className="grid place-items-center py-24">
        <div className="text-center max-w-md">
          <h2 className="text-2xl font-semibold">Sem produtos ainda 😶‍🌫️</h2>
          <p className="text-slate-600 mt-2">
            Vai lá em <span className="font-semibold">Cadastrar</span> e adiciona o primeiro.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section>
      <h2 className="text-xl font-semibold mb-4">Produtos</h2>

      <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {produtos.map((p) => (
          <li
            key={p.id}
            className="group overflow-hidden rounded-2xl border bg-white shadow-sm hover:shadow-lg transition-shadow"
          >
            <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100">
              {p.imagem ? (
                <img
                  src={p.imagem}
                  alt={p.nome}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                />
              ) : (
                <div className="grid h-full w-full place-items-center text-slate-400">
                  sem imagem
                </div>
              )}
            </div>

            <div className="p-4">
              <h3 className="line-clamp-1 text-base font-semibold">{p.nome}</h3>
              <p className="mt-1 line-clamp-2 text-sm text-slate-600">
                {p.descricao}
              </p>
              <div className="mt-3 text-lg font-bold tracking-tight">
                {formatBRL(p.preco)}
              </div>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
