/** Sider bar para login/cadastrp*/
import { Home, ShoppingBag, Settings, LogOut, Package, Hamburger } from "lucide-react";
import ThemeSwitcher from "./ThemeSwitcher";
import "../styles/side-bar.css";

export default function SidebarUser({ open, onClose }) {
  if (!open) return null;

  const menuItems = [
    { icon: Home,       label: "Início",         href: "/home" },
    { icon: Hamburger,  label: "Sobre Nós",      href: "/about" },
  ];

  const handleClick = (item, e) => {
    e.preventDefault();
    // rola até seções quando for hash (#id)
    if (item.href?.startsWith("#")) {
      const el = document.querySelector(item.href);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
      onClose?.();
      return;
    }
    // por enquanto, links "normais" seguem o href (vai recarregar se for fora do SPA)
    window.location.href = item.href || "/";
    onClose?.();
  };

  return (
    <>
      <div className="sidebar-user">
        {/* Cabeçalho */}
        <div className="sidebar-user__header">
          <span className="sidebar-user__title">MENU</span>
          <button className="sidebar-user__close" onClick={onClose}>✕</button>
        </div>

        {/* Navegação */}
        <nav className="sidebar-user__nav">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <a
                key={index}
                href={item.href}
                className="menu-item"
                onClick={(e) => handleClick(item, e)}
              >
                <Icon />
                <span>{item.label}</span>
              </a>
            );
          })}
        </nav>

        {/* Rodapé */}
        <div className="sidebar-user__footer">
          <ThemeSwitcher />
          <p style={{ margin: "0.5rem 0" }}>Versão 1.0.0</p>
          <p style={{ margin: "0.5rem 0" }}>© 2025 - Basilios</p>
        </div>
      </div>

      {/* Overlay */}
      <div className="sidebar-overlay" role="button" tabIndex={0} onClick={onClose} onKeyDown={(e) => e.key === "Enter" && onClose()} aria-label="Fechar menu" />
    </>
  );
}
