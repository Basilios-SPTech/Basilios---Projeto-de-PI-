import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  useNavigate,
  Outlet,
} from "react-router-dom";
import { Toaster } from "react-hot-toast";

// Pages
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import ForgotPassword from "./pages/ForgotPassword.jsx";
import ResetPassword from "./pages/ResetPassword.jsx";
import FooterBasilios from "./components/FooterBasilios.jsx";
import About from "./pages/About.jsx";
import Home from "./pages/Home.jsx";
import CadastrarProduto from "./pages/CadastrarProduto.jsx";
import OrdersBoard from "./pages/OrdersBoard.jsx";
import CheckoutPage from "./pages/CheckoutPage.jsx";
import PixCheckout from "./pages/PixCheckout.jsx";
import StatusOrderPage from "./pages/StatusOrderPage.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import PromocoesPage from "./pages/PromocoesPage.jsx";
import { ProfilePage } from "./pages/ProfilePage.jsx";
// Layouts
import AuthLayout from "./layouts/AuthLayout.jsx";
import RequireAuth from "./routes/RequireAuth.jsx";

// Auth storage
import { authStorage } from "./services/storageAuth.js";
import ScrollToTop from "./components/ScrollToTop.jsx";

/* ============================
   Guards/Routes helpers
============================ */

// Se já estiver logado, não faz sentido ver login/register
function PublicRoute() {
  return authStorage.isAuthenticated() ? (
    <Navigate to="/home" replace />
  ) : (
    <Outlet />
  );
}

/* ============================
   Wrappers (rotas com layout)
============================ */

function LoginRoute() {
  const navigate = useNavigate();

  const goForgotWithEmail = (typedEmail = "") => {
    const params = new URLSearchParams();
    const cleaned = String(typedEmail || "").trim();
    if (cleaned) params.set("email", cleaned);
    const query = params.toString();
    navigate(query ? `/forgot-password?${query}` : "/forgot-password");
  };

  return (
    <>
      <AuthLayout>
        <Login
          onGoRegister={() => navigate("/register")}
          onGoHome={() => navigate("/home")}
          onGoForgot={goForgotWithEmail}
        />
      </AuthLayout>
      <FooterBasilios />
    </>
  );
}

function RegisterRoute() {
  const navigate = useNavigate();
  return (
    <>
      <AuthLayout>
        <Register onGoLogin={() => navigate("/login")} />
      </AuthLayout>
      <FooterBasilios />
    </>
  );
}

function ForgotPasswordRoute() {
  return (
    <>
      <AuthLayout>
        <ForgotPassword />
      </AuthLayout>
      <FooterBasilios />
    </>
  );
}

function ResetPasswordRoute() {
  return (
    <>
      <AuthLayout>
        <ResetPassword />
      </AuthLayout>
      <FooterBasilios />
    </>
  );
}

function BoardRoute() {
  const navigate = useNavigate();
  return <OrdersBoard onGoOrdersBoard={() => navigate("/board")} />;
}

function CheckoutRoute() {
  const navigate = useNavigate();
  return <CheckoutPage onGoCheckout={() => navigate("/checkout")} />;
}

function PixRoute() {
  const navigate = useNavigate();
  return (
    <>
      <PixCheckout onGoCheckout={() => navigate("/pix-checkout")} />
      <FooterBasilios />
    </>
  );
}

function OrderStatusRoute() {
  const navigate = useNavigate();
  return <StatusOrderPage onGoOrderStatus={() => navigate("/order-status")} />;
}

function HomePage() {
  const navigate = useNavigate();
  return <Home onGoHome={() => navigate("/home")} />;
}

function CadastrarProdutoRoute() {
  const navigate = useNavigate();
  return (
    <CadastrarProduto onGoCadastrarProduto={() => navigate("/cadastro")} />
  );
}

/* ============================
   Layout público (produtos)
============================ */

function ProdutoLayout({ children }) {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
    </div>
  );
}

/* ============================
   App
============================ */

export default function App() {
  return (
    <div className="min-h-dvh flex flex-col">
      <main className="flex-1">
        <Router>
          <ScrollToTop />
          <Toaster position="top-center" />

          <Routes>
            <Route path="/" element={<Navigate to="/home" replace />} />

            {/* Públicas */}
            <Route
              path="/about"
              element={
                <>
                  <About />
                  <FooterBasilios />
                </>
              }
            />

            {/* Login/Register públicas, mas se já logado, manda pra /home */}
            <Route element={<PublicRoute />}>
              <Route path="/login" element={<LoginRoute />} />
              <Route path="/register" element={<RegisterRoute />} />
            </Route>

            {/* Recuperação de senha deve abrir sempre, mesmo com sessão ativa */}
            <Route
              path="/forgot-password"
              element={<ForgotPasswordRoute />}
            />
            <Route
              path="/reset-password"
              element={<ResetPasswordRoute />}
            />

            {/* Home é pública (carrinho funciona sem login) */}
            <Route
              path="/home"
              element={
                <>
                  <ProdutoLayout>
                    <HomePage />
                  </ProdutoLayout>
                  <FooterBasilios />
                </>
              }
            />

            {/* Rotas autenticadas para CLIENTE e FUNCIONARIO */}
            <Route
              element={
                <RequireAuth roles={["ROLE_CLIENTE", "ROLE_FUNCIONARIO"]} />
              }
            >
              <Route
                path="/profile"
                element={
                  <>
                    <ProdutoLayout>
                      <ProfilePage />
                    </ProdutoLayout>
                    <FooterBasilios />
                  </>
                }
              />

              <Route path="/checkout" element={<CheckoutRoute />} />
              <Route path="/pix-checkout" element={<PixRoute />} />
              <Route path="/order-status" element={<StatusOrderPage />} />
            </Route>

            {/* Rotas exclusivas de FUNCIONARIO */}
            <Route element={<RequireAuth roles={["ROLE_FUNCIONARIO"]} />}>
              <Route
                path="/cadastro"
                element={
                  <ProdutoLayout>
                    <CadastrarProdutoRoute />
                  </ProdutoLayout>
                }
              />

              <Route path="/board" element={<BoardRoute />} />

              <Route
                path="/dashboard"
                element={
                  <ProdutoLayout>
                    <Dashboard />
                  </ProdutoLayout>
                }
              />

              <Route
                path="/promocoes"
                element={
                  <ProdutoLayout>
                    <PromocoesPage />
                  </ProdutoLayout>
                }
              />
            </Route>

            {/* 404 -> home */}
            <Route path="*" element={<Navigate to="/home" replace />} />
          </Routes>
        </Router>
      </main>
    </div>
  );
}
